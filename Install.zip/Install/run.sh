sleep 5

if [ -f /Agora/Agora-master/Agora.jar ]; then

	rm /Agora/version
	mv /Agora/Agora-master/version /Agora/version

	rm /Agora/Agora.jar
	mv /Agora/Agora-master/Agora.jar /Agora/Agora.jar



fi

java -jar /Agora/Agora.jar
